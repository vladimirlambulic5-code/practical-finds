/* PF_BUILD:2025-10-04-b  &mdash;  Practical Finds auto-sections (blogs only) */
(function () {
  function ready(fn){ if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",fn);} else { fn(); } }

  ready(function () {
    // 0) Radi samo na BLOG postovima (ne diramo listicles hub/listicle stranice)
    var path = (location.pathname||"").toLowerCase();
    if (path.indexOf("/pages/listicles/") !== -1 || /\/listicles\.html$/.test(path)) return;

    // 0.1) Ako je već rađeno, ne duplirati
    if (document.documentElement.hasAttribute("data-pf-sectionized")) return;

    // 0.2) Helperi
    var IN_HF_SEL = "header, .site-header, footer, .site-footer, nav";
    function inHeaderFooter(el){ return !!(el && el.closest && el.closest(IN_HF_SEL)); }
    function isBoundary(el){
      if (!el || el.nodeType !== 1) return false;
      if (inHeaderFooter(el)) return true;
      var txt = (el.innerText||"").trim().toLowerCase();
      return el.classList.contains("disclosure") || txt === "share now!" || txt.indexOf("share now!")===0;
    }
    function slug(s){
      return String(s||"")
        .toLowerCase()
        .replace(/&[a-z]+;|&#?\d+;?/g, " ")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");
    }
    // <p><strong>NASLOV</strong></p> bez drugog teksta
    function isWholeStrong(el){
      var nodes = Array.prototype.slice.call(el.childNodes||[]);
      if (!nodes.length) return false;
      for (var i=0;i<nodes.length;i++){
        var n = nodes[i];
        if (n.nodeType === 3 && /\S/.test(n.nodeValue||"")) return false;
        if (n.nodeType === 1 && !/^(STRONG|B)$/i.test(n.tagName)) return false;
      }
      return true;
    }

    // 1) Pronađi scope: prvo data-pf-article, inače smart izbor
    function pickScope(){
      var candidates = ["main .container", "article .container", ".finds", "main.container", "main", ".container"];
      var best=null, bestScore=-1;
      for (var i=0;i<candidates.length;i++){
        var el = document.querySelector(candidates[i]);
        if (!el || inHeaderFooter(el)) continue;
        var pCount = el.querySelectorAll("p, li").length;
        var tLen = ((el.innerText||"").trim()).length;
        var score = (pCount >= 2 ? pCount * 12 : pCount * 8) + Math.min(2000, tLen/20);
        if (score > bestScore){ best = el; bestScore = score; }
      }
      return best && !inHeaderFooter(best) ? best : null;
    }
    var explicit = document.querySelector("[data-pf-article]");
    var scope = (explicit && !inHeaderFooter(explicit)) ? explicit : pickScope();
    if (!scope){ console.log("[PF:auto-sections] scope not found (safe exit)"); return; }

    // 2) Mini CSS (jednom)
    if (!document.getElementById("pf-sections-css")){
      var style = document.createElement("style");
      style.id = "pf-sections-css";
      style.textContent =
        ".pf-sec{margin:20px 0 12px;padding-top:12px;border-top:1px solid #1f2937}"
      + ".pf-sec h3{margin:0 0 8px;font-size:20px;line-height:1.25;color:#F5F8FF}"
      + ".pf-sec p{margin:6px 0;color:#d4deea}"
      + ".pf-sec ul{margin:8px 0 0 18px;color:#d4deea}"
      + ".pf-sec li{margin:4px 0}"
      + "nav.subtoc{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 18px}"
      + "nav.subtoc a{font-size:14px;padding:6px 10px;border:1px solid #324155;border-radius:8px;text-decoration:none;color:#d4deea}"
      + "nav.subtoc a:hover{border-color:#5973a7;color:#ffffff}";
      document.head.appendChild(style);
    }

    var STATIC_HEADINGS = [
      "why it matters",
      "quick buy checklist",
      "frequently asked questions",
      "faq",
      "amazon highlight",
      "additional information",
      "quick tips"
    ];

    // 3) Root text čvorovi u scope-u -> <p>
    (function wrapRootTextNodes(){
      var toWrap=[];
      (scope.childNodes||[]).forEach ? scope.childNodes.forEach(function(n){
        if (n.nodeType===3 && (n.nodeValue||"").trim()) toWrap.push(n);
      }) : [].slice.call(scope.childNodes||[]).forEach(function(n){
        if (n.nodeType===3 && (n.nodeValue||"").trim()) toWrap.push(n);
      });
      toWrap.forEach(function(n){
        var frag = document.createDocumentFragment();
        String(n.nodeValue||"").split(/\r?\n/).forEach(function(line){
          var t = line.trim(); if (!t) return;
          var p = document.createElement("p"); p.textContent=t;
          frag.appendChild(p);
        });
        n.replaceWith(frag);
      });
    })();

    // 4) Normalizuj elemente bez &ldquo;blokova&rdquo;: <br> ili \n -> više <p>
    (function normalizeLines(){
      var nodes = Array.prototype.slice.call(scope.querySelectorAll("p, div, section, article, span"));
      var changed=0;
      nodes = nodes.filter(function(el){
        if (isBoundary(el)) return false;
        if (!el.parentElement || inHeaderFooter(el.parentElement)) return false;
        if (el.querySelector("p, div, section, article, ul, ol, table, h1, h2, h3")) return false;
        return true;
      });
      nodes.forEach(function(el){
        var html = el.innerHTML || "";
        var text = el.textContent || "";
        if (/<br\s*\/?>/i.test(html)){
          var parts = html.split(/<br\s*\/?>/gi).map(function(s){return s.trim();}).filter(Boolean);
          if (parts.length>1){
            var frag = document.createDocumentFragment();
            parts.forEach(function(part){ var p=document.createElement("p"); p.innerHTML=part; frag.appendChild(p); });
            el.replaceWith(frag); changed++; return;
          }
        }
        if (text.indexOf("\n")!==-1){
          var raw = text.split(/\r?\n/).map(function(s){return s.trim();}).filter(Boolean);
          if (raw.length>1){
            var frag2 = document.createDocumentFragment();
            raw.forEach(function(line){ var p2=document.createElement("p"); p2.textContent=line; frag2.appendChild(p2); });
            el.replaceWith(frag2); changed++;
          }
        }
      });
      console.log("[PF:auto-sections] normalized blocks:", changed);
    })();

    // 5) Kandidati za naslove
    var candidates = Array.prototype.slice.call(scope.querySelectorAll("p, div, section, article, span")).filter(function(el){
      if (isBoundary(el)) return false;
      var raw = String(el.textContent||"").replace(/\s+/g," ").trim();
      if (!raw) return false;
      if (/^\d{1,2}\)\s+.+/.test(raw)) return true;           // "1) ..."
      if (isWholeStrong(el)) return true;                     // <strong>Naslov</strong>
      var low = raw.toLowerCase().replace(/\s*:\s*$/,"");     // statični
      return STATIC_HEADINGS.indexOf(low)!==-1;
    });

    if (!candidates.length){
      document.documentElement.setAttribute("data-pf-sectionized","1");
      console.log("[PF:auto-sections] no candidates (safe exit). Scope:", scope);
      return;
    }

    // 6) Kreiraj sekcije i prebaci sadržaj
    var sections=[], used={};
    function uniq(id){ var k=id, i=2; while(used[k]) k=id+"-"+(i++); used[k]=1; return k; }

    candidates.forEach(function(el){
      var heading = String(el.textContent||"").trim().replace(/^\s*\d{1,2}\)\s+/, "").replace(/\s*:\s*$/,"");
      if (isWholeStrong(el)) heading = String(el.textContent||"").trim().replace(/\s*:\s*$/,"");
      if (!heading) return;

      var sec = document.createElement("section"); sec.className="pf-sec";
      var h3 = document.createElement("h3"); h3.textContent=heading; h3.id=uniq("sec-"+slug(heading));
      sec.appendChild(h3);
      el.replaceWith(sec);
      sections.push(sec);
    });

    function moveUntilNextSection(current, stop){
      while (current.nextSibling && current.nextSibling!==stop){
        var n = current.nextSibling;
        if (n.nodeType===1 && (isBoundary(n) || inHeaderFooter(n))) break;
        current.appendChild(n);
      }
    }
    for (var i=0;i<sections.length;i++){ moveUntilNextSection(sections[i], sections[i+1]||null); }

    sections.forEach(function(sec){
      Array.prototype.slice.call(sec.childNodes||[]).forEach(function(n){
        if (n.nodeType===3 && (n.nodeValue||"").trim()){
          var p=document.createElement("p"); p.textContent=(n.nodeValue||"").trim(); sec.replaceChild(p,n);
        } else if (n.nodeType===1 && n.tagName==="BR"){
          var p2=document.createElement("p"); p2.innerHTML="&nbsp;"; sec.replaceChild(p2,n);
        }
      });
      Array.prototype.slice.call(sec.querySelectorAll("p")).forEach(function(p){
        p.innerHTML = p.innerHTML.replace(/<br\s*\/?>\s*/gi," ");
      });
    });

    // 7) TOC posle H1/H2 u scope-u (3+ sekcije)
    var title = scope.querySelector("h1, h2");
    if (title && sections.length>=3){
      var toc=document.createElement("nav"); toc.className="subtoc"; toc.setAttribute("aria-label","On this page");
      toc.innerHTML = sections.map(function(sec,i){
        var h = sec.querySelector("h3"); if (!h) return "";
        var txt = (h.textContent||"").trim();
        return '<a href="#'+h.id+'">'+(i+1)+') '+txt+'</a>';
      }).join("");
      title.after(toc);
    }

    document.documentElement.setAttribute("data-pf-sectionized","1");
    console.log("[PF:auto-sections] OK. Sections:", sections.length, "Scope:", scope);
  });
})();


/* === Sanitize stray text nodes like "nnn" and keep only canonical share === */
document.addEventListener('DOMContentLoaded', () => {
  try {
    // Remove accidental 'nnn' text nodes that sometimes slip in above comments
    document.querySelectorAll('main, article').forEach(scope => {
      Array.from(scope.childNodes).forEach(node => {
        if (node && node.nodeType === 3 && node.textContent && node.textContent.trim() === 'nnn') {
          node.remove();
        }
      });
    });
    // If multiple share blocks exist, prefer #share-bottom (or #share-top) and hide others in-article via CSS.
    // No DOM shuffling here to avoid breaking icons&mdash;CSS handles visibility.
  } catch (e) { /* silent */ }
});



/* === Ensure FAQ block is above in-article #share-bottom, non-destructive === */
document.addEventListener('DOMContentLoaded', () => {
  try {
    const article = document.querySelector('main article.prose');
    if (!article) return;
    // find FAQ h2 (exact text 'FAQ', case-insensitive)
    const faqH2 = Array.from(article.querySelectorAll('h2')).find(h => (h.textContent || '').trim().toLowerCase() === 'faq');
    if (!faqH2) return;

    // if share-bottom is inside the article, ensure FAQ block sits above it
    const bottom = article.querySelector('#share-bottom');
    if (bottom && bottom.parentElement === article) {
      const relation = faqH2.compareDocumentPosition(bottom);
      const bottomIsBeforeFaq = (relation & Node.DOCUMENT_POSITION_PRECEDING) !== 0;
      if (bottomIsBeforeFaq) {
        const frag = document.createDocumentFragment();
        // move H2 + following siblings until next H2 (or end) into a fragment
        let n = faqH2;
        while (n) {
          const next = n.nextSibling;
          frag.appendChild(n);
          if (n.nodeType === 1 && n.tagName === 'H2' && n !== faqH2) break;
          if (n && n.nodeType === 1 && /^H\d$/i.test(n.tagName) && n !== faqH2) break;
          n = next;
        }
        article.insertBefore(frag, bottom);
      }
    }

    // Clean stray 'nnn' text nodes that might appear as separate text nodes
    document.querySelectorAll('main, article').forEach(scope => {
      Array.from(scope.childNodes).forEach(node => {
        if (node && node.nodeType === 3 && node.textContent && node.textContent.trim() === 'nnn') {
          node.remove();
        }
      });
    });
  } catch (e) {
    // no-op on error
  }
});

