/* === TOC sidebar generator v2 (inner wrapper; non-invasive) === */
(function(){
  try{
    var main = document.querySelector('main.pf-container');
    var article = document.querySelector('article.prose');
    if(!main || !article) return;

    // Collect H2 headings
    var headings = Array.prototype.slice.call(article.querySelectorAll('h2')).filter(function(h){
      return (h.textContent || '').trim().length > 0;
    });
    if(headings.length < 2) return; // skip if nema dovoljno sekcija

    // Slug helper
    function slug(s){
      return (s||'').toLowerCase()
        .replace(/[^a-z0-9\s-]/g,'')
        .trim().replace(/\s+/g,'-').replace(/-+/g,'-');
    }

    // Ensure IDs
    headings.forEach(function(h){
      if(!h.id) h.id = 'sec-' + slug(h.textContent);
    });

    // Build sidebar
    var aside = document.createElement('aside');
    aside.className = 'toc-sidebar';
    aside.innerHTML = '<h3>Table of contents</h3><ol class="toc-list"></ol>';
    var list = aside.querySelector('.toc-list');

    headings.forEach(function(h){
      var li = document.createElement('li');
      var a  = document.createElement('a');
      a.href = '#' + h.id;
      var txt = (h.textContent || '').trim();
      a.textContent = txt;
      if (txt.length > 60) a.title = txt;
      li.appendChild(a);
      list.appendChild(li);
    });

    // Create wrapper and place article + TOC inside (content | toc)
    var wrap = document.createElement('div');
    wrap.className = 'pf-article-wrap has-toc';
    // Insert wrapper right before article, then move article and append aside
    main.insertBefore(wrap, article);
    wrap.appendChild(article);
    wrap.appendChild(aside);

    // Active link highlight via IntersectionObserver
    var anchors = Array.prototype.slice.call(list.querySelectorAll('a'));
    var map = {};
    anchors.forEach(function(a){ map[a.getAttribute('href').slice(1)] = a; });

    var io = new IntersectionObserver(function(entries){
      var best = null, bestTop = Infinity;
      entries.forEach(function(e){
        if(e.isIntersecting && e.boundingClientRect.top < bestTop){
          bestTop = e.boundingClientRect.top; best = e.target;
        }
      });
      if(best){
        anchors.forEach(function(a){ a.classList.remove('is-active'); });
        var link = map[best.id];
        if(link) link.classList.add('is-active');
      }
    }, { rootMargin: '0px 0px -70% 0px', threshold: [0, 0.1, 1] });

    headings.forEach(function(h){ io.observe(h); });
  }catch(e){
    // silent fail
    if (window.console && console.debug) console.debug('TOC v2 init skipped:', e);
  }
})();
