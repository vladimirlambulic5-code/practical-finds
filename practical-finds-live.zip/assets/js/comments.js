/* Lightweight localStorage comments &mdash; PONEDE
   No servers, no cookies. Works with existing markup:
   <ul id="comments-list">, <form id="comments-form">, #name-input, #comment-input
*/
(function(){
  const list = document.getElementById('comments-list');
  const form = document.getElementById('comments-form');
  const nameInput = document.getElementById('name-input');
  const commentInput = document.getElementById('comment-input');
  if(!list || !form || !nameInput || !commentInput){ return; } // Not on this page

  // Per-page storage key
  const KEY = 'pf_comments::' + (location.pathname || 'index');
  let data;
  try { data = JSON.parse(localStorage.getItem(KEY) || '[]'); }
  catch(e){ data = []; }

  // Session id to allow edit/delete for own comments in this tab
  let SESSION = sessionStorage.getItem('pf_comment_session');
  if(!SESSION){
    SESSION = (Math.random().toString(36).slice(2) + Date.now().toString(36));
    sessionStorage.setItem('pf_comment_session', SESSION);
  }

  // Honeypot (basic bot trap)
  let hp = form.querySelector('input[name="website"]');
  if(!hp){
    hp = document.createElement('input');
    hp.type = 'text';
    hp.name = 'website';
    hp.autocomplete = 'off';
    hp.tabIndex = -1;
    hp.style.position='absolute';
    hp.style.left='-9999px';
    hp.style.width='1px';
    form.appendChild(hp);
  }

  // Escape text for safe HTML
  const esc = s => String(s)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');

  // State for editing
  let editingId = null;

  function save(){
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  function fmtTime(ts){
    try {
      const d = new Date(ts);
      return d.toLocaleDateString(undefined, {year:'numeric', month:'short', day:'2-digit'});
    } catch(e){ return ''; }
  }

  function render(){
    list.innerHTML = '';
    if(!data.length){
      const li = document.createElement('li');
      li.className = 'comment empty';
      li.style.opacity = '0.8';
      li.textContent = 'Be the first to comment.';
      list.appendChild(li);
      return;
    }
    data.forEach(item => {
      const li = document.createElement('li');
      li.className = 'comment';
      // Name (bold) + message + optional small actions
      const strong = document.createElement('strong');
      strong.textContent = item.name || 'Anonymous';
      const msg = document.createElement('span');
      msg.className = 'msg';
      msg.innerHTML = ' ' + esc(item.text);

      li.appendChild(strong);
      li.appendChild(msg);

      // Time (muted)
      if(item.ts){
        const small = document.createElement('small');
        small.style.marginLeft = '6px';
        small.style.opacity = '0.6';
        small.textContent = '&bull; ' + fmtTime(item.ts);
        li.appendChild(small);
      }

      // Actions for owner
      if(item.session === SESSION){
        const wrap = document.createElement('span');
        wrap.style.marginLeft = '8px';
        // Edit
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.textContent = 'Edit';
        editBtn.title = 'Edit your comment';
        editBtn.style.marginLeft = '4px';
        editBtn.style.fontSize = '.8rem';
        editBtn.style.border = '0';
        editBtn.style.background = 'transparent';
        editBtn.style.cursor = 'pointer';
        editBtn.style.color = 'inherit';
        editBtn.addEventListener('click', () => {
          editingId = item.id;
          nameInput.value = item.name || '';
          commentInput.value = item.text || '';
          nameInput.focus();
          submitBtn.textContent = 'Save';
        });
        // Delete
        const delBtn = document.createElement('button');
        delBtn.type = 'button';
        delBtn.textContent = 'Delete';
        delBtn.title = 'Delete this comment';
        delBtn.style.marginLeft = '6px';
        delBtn.style.fontSize = '.8rem';
        delBtn.style.border = '0';
        delBtn.style.background = 'transparent';
        delBtn.style.cursor = 'pointer';
        delBtn.style.color = 'inherit';
        delBtn.addEventListener('click', () => {
          const idx = data.findIndex(x => x.id === item.id);
          if(idx >= 0){
            data.splice(idx,1);
            save(); render();
          }
        });
        wrap.appendChild(editBtn);
        wrap.appendChild(delBtn);
        li.appendChild(wrap);
      }

      list.appendChild(li);
    });
  }

  function validate(){
    const name = (nameInput.value || '').trim();
    const text = (commentInput.value || '').trim();
    if(name.length < 2 || text.length < 2) return false;
    if(name.length > 80 || text.length > 600) return false;
    return true;
  }

  const submitBtn = form.querySelector('button[type="submit"], [type="submit"]') || form.querySelector('button');

  form.addEventListener('submit', (ev) => {
    ev.preventDefault();
    if(hp && hp.value){ return; } // bot
    if(!validate()){ return; }

    const name = (nameInput.value || '').trim();
    const text = (commentInput.value || '').trim();

    if(editingId){
      const item = data.find(x => x.id === editingId);
      if(item && item.session === SESSION){
        item.name = name; item.text = text; item.ts = Date.now();
        editingId = null;
        submitBtn.textContent = 'Add Comment';
      }
    } else {
      const item = {
        id: Math.random().toString(36).slice(2) + Date.now().toString(36),
        name, text,
        ts: Date.now(),
        session: SESSION
      };
      data.push(item);
    }
    save();
    render();
    form.reset();
  });

  render();
})();