(function(){
  /* ---------- helpers ---------- */
  function cleanUtilityClasses(a){
    if(!a || !a.className) return;
    a.className = a.className
      .split(/\s+/)
      .filter(function(c){ return !/^tw-bg-/.test(c) && !/^tw-rounded-/.test(c) && !/^tw-text-/.test(c); })
      .join(' ');
    a.removeAttribute('style');
  }
  function svg(icon){
    if(icon==='meta')   return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 16.6c-1.6 0-3-2.3-4.1-4.1-1.1-1.8-2.2-3.6-3.7-3.6-1.7 0-2.8 2.1-3.5 3.6-.5 1.2-1.2 4.1-2.4 4.1C3.2 16.6 2 14.6 2 12.1 2 8.7 4.1 6 7 6c2.6 0 4 2 5.8 4.7l.4.6c.7 1.1 1.8 3.3 2.8 3.3.9 0 1.3-1.2 1.3-2.6C17.3 9 16 7 14 7c-.6 0-1.2.2-1.7.5l-.9-1.1C12.2 6 13 5.7 14 5.7c3 0 5 2.7 5 6.2 0 2.7-1.2 4.7-2.3 4.7z"/></svg>';
    if(icon==='fb')     return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3h-2c-2.21 0-4 1.79-4 4v2H7v3h2v9h3v-9h2.25L15 9h-3V7c0-.55.45-1 1-1H15V3z"/></svg>';
    if(icon==='x')      return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l8.2 9.4L3.6 21H7l5.5-6.6L18.5 21H21l-8.1-9.2L20.4 3H17L11.9 9.1 6.6 3H3z"/></svg>';
    if(icon==='wa')     return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 3.9A10 10 0 005.2 19.6L3 21l1.5-3A10 10 0 1020 3.9zm-8.1 3.2c.3 0 .6 0 .9.1.2.1.5.5.6 1 .1.5.4 1.4.4 1.4s.1.3 0 .5c0 .2-.2.4-.4.6-.2.2-.5.5-.5.5s-.1.2 0 .4c.1.2.4.7.9 1.1.6.5 1.1.7 1.3.8.2.1.3.1.5 0 .1-.1.8-.9.8-.9s.2-.2.4-.2.4 0 .6 0 .6.2 1 .4c.3.1.9.4.9.4s.3.1.3.4c0 .2 0 .5-.1.7-.1.2-.6 1.1-1.4 1.5-.8.4-1.8.4-3 0-1.2-.4-2.7-1.2-3.8-2.3-1.1-1.1-1.9-2.6-2.3-3.8-.4-1.2-.4-2.2 0-3 .4-.8 1.3-1.3 1.5-1.4.2-.1.5-.1.7-.1z"/></svg>';
    if(icon==='mail')   return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>';
    if(icon==='pin')    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2C7.6 2 4 5.6 4 10c0 3.2 1.9 5.9 4.6 6.9-.1-.6-.2-1.6 0-2.3.2-.7 1.2-4.7 1.2-4.7s-.3-.6-.3-1.5c0-1.4.8-2.5 1.8-2.5.8 0 1.2.6 1.2 1.4 0 .8-.5 2.1-.8 3.3-.2 1 .5 1.8 1.5 1.8 1.8 0 3.1-1.9 3.1-4.6 0-2.4-1.7-4.1-4.2-4.1-2.8 0-4.5 2.1-4.5 4.3 0 .8.3 1.6.7 2.1-.1.1-.1.2-.1.3-.1.3-.2 1-.2 1.1 0 .2-.2.3-.4.2-1.2-.5-2-2-2-3.2 0-2.7 2-5.1 5.8-5.1 3 0 5.3 2.1 5.3 5.1 0 3-1.9 5.4-4.5 5.4-.9 0-1.8-.5-2.1-1.1l-.6 2.2c-.2.8-.8 1.8-1.2 2.4.9.3 1.9.5 3 .5 4.4 0 8-3.6 8-8S16.4 2 12 2z"/></svg>';
    if(icon==='reddit') return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 12c0 4.4-4.5 8-10 8S2 16.4 2 12s4.5-8 10-8c1.7 0 3.3.4 4.7 1.1l1.1-2.6 2.4.6-1.6 3.7c1.7 1.4 2.4 3.1 2.4 5.2zM7.5 13c0 .8.8 1.5 1.8 1.5s1.8-.7 1.8-1.5-.8-1.5-1.8-1.5S7.5 12.2 7.5 13zm9 0c0 .8-.8 1.5-1.8 1.5s-1.8-.7-1.8-1.5.8-1.5 1.8-1.5 1.8.7 1.8 1.5zM12 18c1.7 0 3.1-.6 3.9-1.5H8.1c.8.9 2.2 1.5 3.9 1.5z"/></svg>';
    return '';
  }
  function styleShareAnchor(a, type, url, title){
    cleanUtilityClasses(a);
    a.setAttribute('target','_blank');
    a.setAttribute('rel','nofollow noopener noreferrer');
    a.classList.add('pf-share-btn','pf-share-'+type);
    if(type==='fb'){ a.innerHTML=svg('fb'); a.href='https://www.facebook.com/sharer/sharer.php?u='+url; }
    if(type==='x'){ a.innerHTML=svg('x'); a.href='https://twitter.com/intent/tweet?url='+url+'&text='+title; }
    if(type==='wa'){ a.innerHTML=svg('wa'); a.href='https://api.whatsapp.com/send?text='+title+'%20'+url; }
    if(type==='mail'){ a.innerHTML=svg('mail'); a.href='mailto:?subject='+title+'&body='+url; }
    if(type==='pin'){ a.innerHTML=svg('pin'); a.href='https://www.pinterest.com/pin/create/button/?url='+url; }
    if(type==='reddit'){ a.innerHTML=svg('reddit'); a.href='https://www.reddit.com/submit?url='+url+'&title='+title; }
  }
  function toast(msg){
    var t=document.createElement('div'); t.className='pf-toast'; t.textContent=msg;
    document.body.appendChild(t); setTimeout(function(){ t.remove(); }, 2000);
  }
  function setupMeta(metaA, url, title){
    cleanUtilityClasses(metaA);
    metaA.removeAttribute('href');
    metaA.classList.add('pf-share-btn','pf-share-meta'); metaA.setAttribute('role','button'); metaA.setAttribute('tabindex','0');
    metaA.innerHTML = svg('meta');
    var wrap=document.createElement('span'); wrap.className='pf-meta-wrap';
    metaA.parentElement.insertBefore(wrap, metaA); wrap.appendChild(metaA);
    var pop=document.createElement('div'); pop.className='pf-meta-popover'; pop.style.display='none';
    var fb=document.createElement('a'); fb.setAttribute('aria-label','Facebook'); styleShareAnchor(fb,'fb',url,title); pop.appendChild(fb);
    var ig=document.createElement('a'); ig.setAttribute('aria-label','Instagram'); cleanUtilityClasses(ig); ig.className='pf-share-btn pf-share-ig';
    ig.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2h10a5 5 0 015 5v10a5 5 0 01-5 5H7a5 5 0 01-5-5V7a5 5 0 015-5zm5 4a6 6 0 100 12 6 6 0 000-12zm6-1.5a1 1 0 110 2 1 1 0 010-2z"/></svg>';
    ig.href='javascript:void(0)';
    ig.addEventListener('click', function(e){
      e.preventDefault();
      var shareData={title:decodeURIComponent(title), url:decodeURIComponent(url)};
      if(navigator.share){ navigator.share(shareData).catch(function(){}); }
      else if(navigator.clipboard && window.isSecureContext){
        navigator.clipboard.writeText(decodeURIComponent(url)).then(function(){ toast('Link copied for Instagram'); });
      }else{
        var ta=document.createElement('textarea'); ta.value=decodeURIComponent(url); document.body.appendChild(ta); ta.select();
        try{ document.execCommand('copy'); toast('Link copied for Instagram'); }catch(e){}
        ta.remove();
      }
    });
    pop.appendChild(ig);
    wrap.appendChild(pop);
    function closeAll(ev){
      if(!wrap.contains(ev.target)){ pop.style.display='none'; document.removeEventListener('click', closeAll); }
    }
    metaA.addEventListener('click', function(e){
      e.preventDefault();
      pop.style.display = (pop.style.display==='none') ? 'flex' : 'none';
      if(pop.style.display==='flex'){ setTimeout(function(){ document.addEventListener('click', closeAll); }, 0); }
    });
    metaA.addEventListener('keydown', function(e){ if(e.key==='Escape'){ pop.style.display='none'; } });
  }
  function buildRow(){ var row=document.createElement('div'); row.className='pf-share-row';
    ['meta','x','wa','pin','mail','reddit'].forEach(function(type){
      var a=document.createElement('a');
      a.setAttribute('aria-label',{meta:'Meta',x:'X/Twitter',wa:'WhatsApp',pin:'Pinterest',mail:'Email',reddit:'Reddit'}[type]);
      row.appendChild(a);
    }); return row;
  }
  function buildWrap(where){
    var wrap=document.createElement('div'); wrap.className='pf-share-wrap '+where;
    var title=document.createElement('div'); title.className='pf-share-title'; title.textContent='Share now!';
    var row=buildRow(); wrap.appendChild(title); wrap.appendChild(row); return wrap;
  }
  function decorateRow(row){
    var url = encodeURIComponent(location.href);
    var title = encodeURIComponent(document.title);
    var order=['meta','x','wa','pin','mail','reddit'];
    row.querySelectorAll('a').forEach(function(a,i){
      var type=order[i]; if(type==='meta'){ setupMeta(a,url,title); } else { styleShareAnchor(a,type,url,title); }
    });
  }

  /* ---------- FIX 1: ne dupliraj TOP ako već postoji ---------- */
  function ensureTopShare(){
    // ako u DOM-u već imamo .pf-share-wrap.pf-top (ručno ili ranije ubačeno) &ndash; ništa
    if(document.querySelector('.pf-share-wrap.pf-top')) return;
    // ako HTML već ima tvoj ručni #share-top &ndash; samo ga zameni (bez dodavanja još jednog)
    var legacyTop = document.getElementById('share-top');
    if(legacyTop){ // zameni njegov toolbar novim redom
      var newWrap = buildWrap('pf-top'); legacyTop.replaceWith(newWrap); decorateRow(newWrap.querySelector('.pf-share-row')); return;
    }
    // u suprotnom napravi novi odmah posle H1
    var h1 = document.querySelector('main h1, article h1, h1'); if(!h1) return;
    var wrap = buildWrap('pf-top'); h1.insertAdjacentElement('afterend', wrap); decorateRow(wrap.querySelector('.pf-share-row'));
  }

  /* ---------- FIX 2: zadrži BOTTOM ako postoji ---------- */
  function normalizeExistingBottom(){
    var legacyBottom = document.getElementById('share-bottom');
    if(!legacyBottom) return;
    // već postoji &ndash; samo ga preformatiraj u naš red
    var newWrap = buildWrap('pf-bottom'); legacyBottom.replaceWith(newWrap); decorateRow(newWrap.querySelector('.pf-share-row'));
  }

  /* ---------- FIX 3: footer share uvek iznad copyright-a ---------- */
  function ensureFooterShare(){
    var footer = document.querySelector('.pf-footer'); if(!footer) return;
    if(footer.querySelector('.pf-share-wrap.pf-footer')) return; // već imamo
    var before = footer.querySelector('.pf-copy'); // ubaci odmah iznad &copy;
    var wrap = buildWrap('pf-footer');
    if(before && before.parentNode){ before.parentNode.insertBefore(wrap, before); }
    else { footer.appendChild(wrap); }
    decorateRow(wrap.querySelector('.pf-share-row'));
    // počisti stari .pf-social (slova f/x/◎/p) ako postoji
    var old = footer.querySelector('.pf-social'); if(old) old.remove();
  }

  function init(){
    ensureTopShare();
    normalizeExistingBottom();
    ensureFooterShare();
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
